import json,random,string
import pandas as pd
import numpy as np
import os
from ibm_watson import SpeechToTextV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator, BearerTokenAuthenticator
from ibm_watson import ApiException
from os.path import join, dirname
import json,ast
import time
#import librosa
import requests
import random
from ibm_cloud_sdk_core import IAMTokenManager

# Configuring Speech To Text
def Configure_STT(params_path = 'Params.json'):
    with open(params_path,'r') as f:
        params = json.load(f)
    authenticator = IAMAuthenticator(params['STT_API_KEY'])
    speech_to_text = SpeechToTextV1(
        authenticator=authenticator
    )
    speech_to_text.set_service_url(params['STT_URL'])
    return speech_to_text

# Perform Speech to Text using IBM STT
def perform_STT(speech_to_text,wav_path):
    try:
        with open(wav_path,'rb') as audio_file:
            speech_recognition_results = speech_to_text.recognize(
                audio=audio_file,
                content_type='audio/wav',
                word_alternatives_threshold=0.9,
                smart_formatting = True,
                speaker_labels = True,
                redaction = True
        ).get_result()
        output_json = json.dumps(speech_recognition_results, indent=2)
        output_json = json.loads(output_json)
        return output_json
    except ApiException as ex:
        print("Method failed with status code " + str(ex.code) + ": " + ex.message)

# Processing and Cleaning STT Output to make Trancripts
def Preprocess_STT_Output(stt_output):
    words = []

    for value in stt_output['results']:
        words.extend(value['alternatives'][0]['timestamps'])

    speaker_lists = []
    current_speaker = None
    for item in stt_output['speaker_labels']:
        speaker = item['speaker']
        if speaker != current_speaker:
            current_speaker = speaker
            speaker_list = []
            speaker_lists.append({'speaker': speaker, 'intervals': speaker_list})
        speaker_list.append({'from': item['from'], 'to': item['to']})
    
    speaker_lists_segments = []
    for item in speaker_lists:
        vals = item['intervals']
        vals = sorted(vals, key=lambda x: x['from'])
        speaker_lists_segments.append({'speaker': item['speaker'], 'intervals': [vals[0]['from'],vals[-1]['to']]})

    for i in range(len(speaker_lists_segments)):
        interval = speaker_lists_segments[i]['intervals']
        text = []
        for word in words:
            if (interval[0]<=word[1]) and (interval[1]>=word[2]):
                text.append(word[0])
        speaker_lists_segments[i]['Text'] = ' '.join(text)
    
    return speaker_lists_segments

# Finalising Transcripts
def MakeTrancript(speaker_lists_segments):
    transcript = ''
    for text in speaker_lists_segments:
        if text['speaker'] == 0:
            sp = 'Person#1 -:- '
        if text['speaker'] == 1:
            sp = 'CCR -:- '
        transcript = str(transcript) + str(sp) + text['Text'].capitalize() + '. \n'
    return transcript

class Prompt:
    def __init__(self, access_token, project_id):
        self.access_token = access_token
        self.project_id = project_id

    def generate(self, input, model_id, parameters):
        wml_url = "https://us-south.ml.cloud.ibm.com/ml/v1-beta/generation/text?version=2023-05-28"
        Headers = {
            "Authorization": "Bearer " + self.access_token,
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        data = {
            "model_id": model_id,
            "input": input,
            "parameters": parameters,
            "project_id": self.project_id
        }
        response = requests.post(wml_url, json=data, headers=Headers)
        if response.status_code == 200:
            return response.json()["results"][0]["generated_text"]
        else:
            return response.text
        

# Configuring Watsonx API_key
def Configure_Watsonx(params_path = 'Params.json'):
    with open(params_path,'r') as f:
        params = json.load(f)
    access_token = IAMTokenManager(
    apikey = params['IAM_API_KEY'], #getpass.getpass("Please enter your api key (hit enter): ")
    url = "https://iam.cloud.ibm.com/identity/token"
).get_token()
    
    return access_token

def Pr_ID(params_path = 'Params.json'):
    with open(params_path,'r') as f:
        params = json.load(f)
    project_id = params['PROJECT_ID']
    return project_id

def Mo_ID(params_path = 'Params.json'):
    with open(params_path,'r') as f:
        params = json.load(f)
    model_id = params['Model_ID']
    return model_id

def Parameters_data(params_path = 'Params.json'):
    with open(params_path,'r') as f:
        params = json.load(f)
    parameters = {
    "decoding_method": params['decoding_method'],
    "max_new_tokens": params['max_new_tokens'],
    "repetition_penalty": params['repetition_penalty']
    }
    return parameters

def pr(output_list):
    
    prompt_input = """I have a conversation between 2 people.
    Consider yourself as an expert Conversation Analyst with high People Skills and Evaluate the following conversation efficiently based on the points given below:

    Input:
     "Person#1 -:- I am looking for a Chinese place in the centre.CCR -:- I have 10 restaurants matching your request. Did you have a price range you would like? Person#1 -:- No, it doesn't matter.CCR -:- Would you like for it to have a certain number of stars?Person#1 -:- No just book at a chinese place in the centre. I need a table for 4 at 15:00 on wednesday please..CCR -:- I have you at Jinling Noodle bar then, reference is OCNH3CJJ . Anything else you need?.Person#1 -:- No that is it. Thank you. CCR -:- Have a great day!"

    Output:
    Summary for this conversation: Customer seeks Chinese restaurant and accommodation recommendations, reservation assistance, and confirms address details.
    Problem Customer is facing: Find restaurant and accommodation options.
    Was CCR able to solve the customer's problem: Yes.
    If CCR was able to solve customer's problem then How he did it, otherwise answer "Not Solved"?: Provided restaurant and accommodation suggestions, made reservation, gave address.
    If CCR was not able to solve customer's problem then why, otherwise answer "Solved"?: N/A (problem solved).
    CCR's tone while talking to Customer: Helpful, informative, accommodating.
    Customer satisfaction using Keywords on how CCR handled his problem: Satisfied, appreciative.
    Score CCR out of 100 on efficient problem understanding and clear communication with the customer: 95 (Efficient problem solving and clear communication, with a minor opportunity for improvement).
    Score CCR out of 100 on overall conversation with the customer in Positive, Negative, and Neutral:
    Positive: 90 
    Negative: 5 
    Neutral: 5
    """
    input1 = f"""{output_list} 
    Output:
    """

    pro = prompt_input + input1
    return pro

def output_generation(transcript,name):
    output_list = {}
    prompt1 = f"""{pr(transcript)}"""
    access = Configure_Watsonx()
    proj_id = Pr_ID()
    model_id= Mo_ID()
    parameters= Parameters_data() 
    prompt = Prompt(access, proj_id)
    response = prompt.generate(prompt1, model_id, parameters)
    #output_list = {"Conversation Content": transcript,"Output": response}
    output_list = {
        f'{name}': {
            'Conversation Content': transcript,
            'Output': response
        }
    }
    try:
        with open('output1.json', 'w') as json_file:
            json.dump(output_list, json_file, indent=4)
    except Exception as e:
        print(f"Error writing to JSON file: {e}")

    return output_list

def Extract_data(data): 
    main_data = {}
    ccr_map = [['QR65','Alice Watson'],['ER23','Ankit Arora'],['UY76','Peter Atkins'],['PO65','Tom Stewart'],['BH44','Robert Evans']]
    for key,value in data.items():
        try:
            if key not in main_data.keys():
                splits = data[key]['Output'].replace('\n\n','\n').split('\n')

                ccr_choice = random.choice(ccr_map)
                file_name = 'Dataset/' + str(key) + '.wav'
                #audio_file = librosa.get_duration(filename=file_name)
                main_data[key] = {'CONV_ID':key,'CCR_ID':ccr_choice[0],'CCR_NAME':ccr_choice[1],'Transcript':data[key]['Conversation Content']}
                for i in splits:
                    if ('Summary' in i):
                        main_data[key]['Summary'] = i.split(': ')[-1]
                    elif ('Problem Customer is facing' in i):
                        main_data[key]['Problem_Intent'] = i.split(': ')[-1]
                    elif ('CCR able to solve' in i):
                        main_data[key]['Solution_Status'] = i.split(': ')[-1]
                    elif ('If CCR was able to solve' in i):
                        main_data[key]['Solution_Provided'] = i.split(': ')[-1]
                    elif ('If CCR was not able to' in i):
                        main_data[key]['Reason_No_Solution'] = i.split(': ')[-1]
                    elif ("CCR's tone" in i):
                        main_data[key]['CCR_Behaviour'] = i.split(': ')[-1]
                    elif ('Customer satisfaction' in i):
                        main_data[key]['User_Feedback'] = i.split(': ')[-1]
                    elif ('100 on efficient problem understanding' in i):
                        main_data[key]['Overall_Rating'] = i.split(': ')[-1]
                    elif ('Positive:' in i):
                        main_data[key]['Conv_Pos_Score'] = i.split(': ')[-1]
                    elif ('Negative:' in i):
                        main_data[key]['Conv_Neg_Score'] = i.split(': ')[-1]
                    elif ('Neutral:' in i):
                        main_data[key]['Conv_Neu_Score'] = i.split(': ')[-1]
                        
            return main_data
        except Exception as e:
            print(e)
            return None
        
# file_path = 'Dataset\\'
def perform_STT1(speech_to_text,file_path):
    print('perform_STT1')
    name1 = {}
    try:
#         print(os.listdir(file_path))
        for filename in os.listdir(file_path):
#             print('in for ',file_path,filename)
            file_p = os.path.join(file_path, filename)
            try:
                with open(file_p,'rb') as audio_file:
                    name = file_p.split('\\')[-1].split('.')[0]
                    speech_recognition_results = speech_to_text.recognize(
                        audio=audio_file,
                        content_type='audio/wav',
                        word_alternatives_threshold=0.9,
                        smart_formatting = True,
                        speaker_labels = True,
                        redaction = True
                ).get_result()
                output_json = json.dumps(speech_recognition_results, indent=2)
                output_json = json.loads(output_json)
               
                name1[name]=output_json
                #print('return ',output_json,name)
#                 return output_json,name
            except ApiException as ex:
                return("Method failed with status code " + str(ex.code) + ": " + ex.message)
    except Exception as e:
        return(f"Error processing folder {file_path}: {e}")
    da=json.dumps(name1,indent=4)
    return da

def main_fun(file_path):
    print('main fun start')
    speech_to_text=Configure_STT()
    conv= perform_STT1(speech_to_text,file_path)
    final_df = []
    finish = []
    f1_data=json.loads(conv)
    for key1,value1 in f1_data.items():
        speaker_lists_segments = Preprocess_STT_Output(value1)
        transcript = MakeTrancript(speaker_lists_segments)
        final_output = output_generation(transcript,key1)
        final_data = Extract_data(final_output)
        final_df.append(final_data)
        
    for dict2 in final_df:
        #print(list(dict2.values()))
        finish.append(list(dict2.values())[0])
    final_res = pd.DataFrame(finish)
    final_res.to_csv('test.csv',index = False)
    final_res['Transcript'] = final_res['Transcript'].str.replace('\n', '<br>') 
    data=final_res.head().to_html(classes='table table-bordered',index=False)
    print('main fun end')   
    return data

# finish = main()
# final_res = pd.DataFrame(finish)
# final_res.to_csv('test.csv',index = False)
