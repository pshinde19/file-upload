import os
from flask import *
import pandas as pd
import time
from watson import main_fun
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'media'
@app.route('/')
def main():   
    return render_template("index.html")


@app.route('/upload', methods=['POST','GET'])
def upload():
        folder_path = app.config['UPLOAD_FOLDER']
        for filename in os.listdir(folder_path):
                file_path = os.path.join(folder_path, filename)
                if os.path.isfile(file_path):
                    os.remove(file_path)
        if request.method == 'POST':
            print(request.files)
            files = request.files.getlist('files')
            print('files',files)
            for file in files:
                  file_path=os.path.join(app.config['UPLOAD_FOLDER'],file.filename)
                  print(file_path)        
                  file.save(file_path)
            parentfolderpath= os.getcwd()+'\media'    
            data=main_fun(parentfolderpath)
            return jsonify(data) 
        # df=pd.read_csv('cad.csv')
        # df.index=None  #.set_index('CONV_ID')
        # df['Transcript'] = df['Transcript'].str.replace('\n', '<br>')
        # print(df['Transcript'])
        # df['Transcript'] = df['Transcript'].str.replace('ccr', '<br>ccr')
        # time.sleep(5)
        # data=df.head().to_html(classes='table table-bordered',index=False)
        # print('end')	
        #     file_path=os.path.join(app.config['UPLOAD_FOLDER'],files.filename)
        #     data=main_fun(file_path)	
        #     data='hello'
        # return jsonify(data)
                       


# def rem_file():
#       # Replace with the path to your folder
#     if os.path.exists(folder_path) and os.path.isdir(folder_path):
#         # Iterate through files in the folder and delete them
#         for filename in os.listdir(folder_path):
#             file_path = os.path.join(folder_path, filename)
#             try:
#                 if os.path.isfile(file_path):
#                     os.unlink(file_path)
#             except Exception as e:
#                 return f"Failed to delete {file_path}: {str(e)}", 500
    
#         return "All files removed successfully."
#     else:
#         return "Folder not found.", 404



if __name__ == '__main__':
	app.run(debug=True)
